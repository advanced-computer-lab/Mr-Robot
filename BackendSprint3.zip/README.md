# Advanced Computer Lab Tasks
### - Before coming to the lab !!
* Make sure that you have **vs code** installed.
* Make sure that you have **node** installed.
* Clone the repositery to your laptop.
* Make sure that the server is running with all installations.
# Testing
### - After Cloning the repo, open the source directory.
```
cd src
```
### - Run the server !
```
node app.js
```
### In case of any missing libraries. 
- please fix and install everything before coming. 

### - Click here to check [Go](http://localhost:8000/home)



### alternative db connection
'mongodb+srv://nadahesham:test1234@cluster0.5uvnx.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'
