import React from 'react';
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
} from "react-router-dom";
import Flights from './Flights';
function Home() {
    return (
        <div>
            <h1>To Travel is to Live</h1>
            <img src="img.png" width="1200" height="400" ></img>
            <img src="image.png" className="image" ></img>


        </div>
    );
}

export default Home;