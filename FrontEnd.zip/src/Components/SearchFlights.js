import React from 'react';
import { useState, useEffect } from "react";
import axios, { Axios } from "axios"
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link,
    useHistory
} from "react-router-dom";


function SearchFlights() {
    let history = useHistory();
    const [FlightNumber, setSearchFlightNumber] = useState(0);
    const [ArrivalTime, setSearchArrivalTime] = useState(0);
    const [DepartureTime, setSearchDeparturetime] = useState(0);
    const [DepartureDate, setSearchDepartureDate] = useState(0);
    const [ArrivalDate, setSearchArrivalDate] = useState(0);
    const [DepartureTerminal, setSearchDepartureTerminal] = useState(0);
    const [ArrivalTerminal, setSearchArrivalTerminal] = useState(0);
    const [sendRequest, setSendRequest] = useState(false);
    // const [searchResults, setSearcResults] = useState({})
    const obj = {
        FlightNumber: FlightNumber,
        ArrivalTime: ArrivalTime,
        DepartureTime: DepartureTime,
        DepartureDate: DepartureDate,
        ArrivalDate: ArrivalDate,
        ArrivalTerminal: ArrivalTerminal,
        DepartureTerminal: DepartureTerminal
    }

    function handleClick(event) {
        history.push('/searchresults')
        axios.post('http://localhost:3001/searchflight', obj).then(() => {
            console.log("yes")
            setSendRequest(true);

        }).catch(err => {
            console.log(err)
            console.log("i am here")
        })


    }

    function handler(event) {
        console.log("i have been clicked")
    }



    return (
        <Router>

            <div className="create">
                <h2>Search a Flight</h2>
                <form>
                    <label>Enter Flight Number</label>
                    <input
                        type="text"

                        // value={flightNumber}
                        name="flightnumber"
                        onChange={(e) => setSearchFlightNumber(e.target.value)}
                    />
                    <label>Enter Arrival Time </label>
                    <input

                        type="text"

                        //  value={arrivalTime}
                        name="arrivaltime"
                        onChange={(e) => setSearchArrivalTime(e.target.value)}
                    />
                    <label>Enter Departure Time</label>
                    <textarea


                        //  value={departure}
                        name="departuretime"
                        onChange={(e) => setSearchDeparturetime(e.target.value)}
                    ></textarea>

                    <label>Enter Departure Date</label>
                    <textarea


                        //  value={departure}
                        name="departuredate"
                        onChange={(e) => setSearchDepartureDate(e.target.value)}
                    ></textarea>



                    <label>Enter Arrival Date</label>
                    <textarea


                        //  value={economySeats}
                        name="economyseats"
                        onChange={(e) => setSearchArrivalDate(e.target.value)}
                    ></textarea>
                    <label>Enter Arrival Terminal</label>
                    <textarea

                        //    value={businessSeats}
                        name="businessseats"
                        onChange={(e) => setSearchArrivalTerminal(e.target.value)}
                    ></textarea>


                    <label>Enter Departure Terminal</label>
                    <textarea

                        //    value={businessSeats}
                        name="businessseats"
                        onChange={(e) => setSearchDepartureTerminal(e.target.value)}
                    ></textarea>





                    <Link to="/searchresults" onClick={handleClick} className="edit"> Search Flight</Link>
                </form>
            </div>

        </Router>
    );



}

export default SearchFlights;