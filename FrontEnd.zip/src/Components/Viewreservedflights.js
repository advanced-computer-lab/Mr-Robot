import react from "react";
import "../index.css"

import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link,
    useHistory

} from "react-router-dom";
import { useState } from 'react';
import { useEffect } from 'react';
import DeletePopup from '../Components/DeletePopup'
import axios from 'axios'

let i = 0;

function Reservedflights() {
    const [popUpBtn, setPopUpBtn] = useState(false);
    const [Viewreservedflights, setreservedflights] = useState([]);
    const [flight, setFlight] = useState({});
    useEffect(() => {
        axios.get('http://localhost:3001/Viewreservedflights').then((response) => {
            setreservedflights(response.data.message);
        });
    }, [Viewreservedflights]);
    const DeleteMe = (event) => {
        event.preventDefault()
        setPopUpBtn(true);
    
    }
    return (
        <div>
            { Viewreservedflights ? Viewreservedflights.map(flight => { 
                return <div className='flights'>
                    <ul >
                        <li>UserID : {flight.UserID} </li>
                        <li>User Email : {flight.UserEmail} </li>
                        <li>Flight Number : {flight.FlightNumber} </li>
                        <li>Arrival Time : {flight.ArrivalTime} </li>
                        <li> Departue Date : {flight.DepartureDate} </li>
                        <li> Arrival Terminal : {flight.ArrivalTerminal} </li>
                        <li> Departure Terminal : {flight.DepartureTerminal} </li>
                        <li> Economy Seats : {flight.EconomySeats}</li>
                       
                        <li> Business Class Seats : {flight.BusinessClassSeats}</li>
                        
                    </ul>
                    <button className="edit" onClick={(event) => {
                        DeleteMe(event)
                        setFlight(flight)
                    }}> Cancel Reservation</button>
                    {/* {setFlightNumber(flight.FlightNumber)} */}
                </div>
            }) : <h1>No Results Found</h1>
            
            }
            <DeletePopup 
            flightnum={flight} trigger={popUpBtn} setTrigger={setPopUpBtn} >
             <h3>Are you sure you want to cancel this flight? </h3>
             </DeletePopup>
        </div>

    )
}


export default Reservedflights