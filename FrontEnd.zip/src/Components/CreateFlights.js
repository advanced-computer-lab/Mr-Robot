import { useState } from "react";
import "../index.css"
import axios, { Axios } from "axios"
const Create = () => {
    const [FlightNumber, setFlightNumber] = useState(0);
    const [ArrivalTime, setArrivalTime] = useState(0);
    const [DepartureTime, setDeparturetime] = useState(0);
    const [DepartureDate, setDepartureDate] = useState(0);
    const [EconomySeats, setEconomySeats] = useState(0);
    const [BusinessClassSeats, setBusinessSeats] = useState(0);
    // const [date, setDate] = useState(0);
    const [ArrivalDate, setArrivalDate] = useState(0);
    const [DepartureAirport, setDepartureAirport] = useState("");
    const [ArrivalAirport, setArrivalAirport] = useState("");
    const [ChildrenSeats, setChildrenSeats] = useState(0);
    const [AdultSeats, setAdultSeats] = useState(0);
    const [BusinessClassSeatPrice, setBusinessClassSeatPrice] = useState(0);
    const [EconomySeatPrice, setEconomySeatPrice] = useState(0);
    const [Cabin, setCabin] = useState("");
    const [TripDuration, setTripDuration] = useState(0);
    const [Baggage, setBaggage] = useState(0);
    const [ArrivalTerminal, setArrivalTerminal] = useState("");
    const [DepartureTerminal, setdepartureTerminal] = useState("");
    const [isAvailable, setAvailable] = useState("ww")

    const [message, setMessage] = useState('')
    const obj = {
        flightN: FlightNumber,
        arrivalT: ArrivalTime,
        DepartureTime: DepartureTime,
        DepartureDate: DepartureDate,
        ArrivalDate: ArrivalDate,
        economy: EconomySeats,
        business: BusinessClassSeats,
        DepartureAirport: DepartureAirport,
        ChildrenSeats: ChildrenSeats,
        AdultSeats: AdultSeats,
        Cabin: Cabin,
        TripDuration: TripDuration,
        Baggage: Baggage,
        ArrivalAirport: ArrivalAirport,
        ArrivalTerminal: ArrivalTerminal,
        DepartureTerminal: DepartureTerminal,
        BusinessClassSeatPrice: BusinessClassSeatPrice,
        EconomySeatPrice: EconomySeatPrice

    }

    function handleClick(event) {
        event.preventDefault()
        axios.post('http://localhost:3001/createflight', obj).then(res => {
            setMessage(res.data)
            console.log(message)
        })

    }
    return (
        <div className="create">
            <h2>Create a new Flight</h2>
            <form>
                <label>Flight number </label>
                <input
                    type="text"

                    // value={flightNumber}
                    name="flightnumber"
                    onChange={(e) => setFlightNumber(e.target.value)}
                />
                <label> Departure Airport</label>
                <input
                    type="text"
                    name="departureairport"
                    onChange={(e) => setDepartureAirport(e.target.value)}
                />
                <label> Arrival Airport</label>
                <input
                    type="text"
                    name="arrivalairport"
                    onChange={(e) => setArrivalAirport(e.target.value)}
                />
                <label> Business Class Seat Price</label>
                <input
                    type="text"
                    name="businessclassseatprice"
                    onChange={(e) => setBusinessClassSeatPrice(e.target.value)}
                />
                <label> Economy Seat Price</label>
                <input
                    type="text"
                    name="economyseatprice"
                    onChange={(e) => setEconomySeatPrice(e.target.value)}
                />
                <label> Children Seats</label>
                <input
                    type="text"
                    name="childrenseats"
                    onChange={(e) => setChildrenSeats(e.target.value)}
                />
                <label> Adult Seats</label>
                <input
                    type="text"
                    name="adultseats"
                    onChange={(e) => setAdultSeats(e.target.value)}
                />
                <label> Trip Duration</label>
                <input
                    type="text"
                    name="tripduration"
                    onChange={(e) => setTripDuration(e.target.value)}
                />
                <label> Cabin</label>
                <input
                    type="text"
                    name="cabin"
                    onChange={(e) => setCabin(e.target.value)}
                />
                <label> Baggage Allowance</label>
                <input
                    type="text"
                    name="baggage"
                    onChange={(e) => setBaggage(e.target.value)}
                />


                <label>Arrival time </label>
                <input

                    type="text"

                    //  value={arrivalTime}
                    name="arrivaltime"
                    onChange={(e) => setArrivalTime(e.target.value)}
                />
                <label>Departure Time</label>
                <textarea


                    //  value={departure}
                    name="departuretime"
                    onChange={(e) => setDeparturetime(e.target.value)}
                ></textarea>

                <label>Departure Date</label>
                <textarea


                    //  value={departure}
                    name="departuredate"
                    onChange={(e) => setDepartureDate(e.target.value)}
                ></textarea>



                <label>Number Of Economy Seats</label>
                <textarea


                    //  value={economySeats}
                    name="economyseats"
                    onChange={(e) => setEconomySeats(e.target.value)}
                ></textarea>
                <label>Number Of Business Class Seats</label>
                <textarea

                    //    value={businessSeats}
                    name="businessseats"
                    onChange={(e) => setBusinessSeats(e.target.value)}
                ></textarea>






                <label>Departure Terminal </label>
                <input
                    type="text"
                    required
                    // value={flightNumber}
                    name="departureterminal"
                    onChange={(e) => setdepartureTerminal(e.target.value)}
                />


                <label>Arrival Terminal </label>
                <input
                    type="text"
                    required
                    // value={flightNumber}
                    name="arrivalterminal"
                    onChange={(e) => setArrivalTerminal(e.target.value)}
                />

                <label>Arrival Date </label>
                <input
                    type="text"
                    required
                    // value={flightNumber}
                    name="arrivaldate"
                    onChange={(e) => setArrivalDate(e.target.value)}
                />




                {/* <select
          value={author}
          onChange={(e) => setAuthor(e.target.value)}
        >
          <option value="business">business</option>
          <option value="economy">economy</option>
        </select> */}
                <button onClick={handleClick}>create</button>




            </form>
            <h4>{message}</h4>
        </div>
    );
}

export default Create;