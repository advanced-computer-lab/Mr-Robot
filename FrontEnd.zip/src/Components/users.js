import React from 'react';
import { useState } from "react";
import "../index.css"
import axios, { Axios } from "axios"

function UpdateUser() {
    const [UserID, setID] = useState(0);
    const [FirstName, setFirstName] = useState(0);
    const [LastName, setLastName] = useState(0);
    const [Email, setEmail] = useState(0);
    const [PassportNumber, setPassportNumber] = useState(0);
    const [Age, setAge] = useState(0);
    const [PhoneNumber, setPhoneNumber] = useState(0);
    const [message, setMessage] = useState("");
    function handleClick(event) {
        event.preventDefault()
        if (obj.UserID === 0) {
            setMessage("Please enter a UserID")
        } else {
            axios.put('http://localhost:3001/updateuser', obj).then(res =>{
                setMessage(res.data)
            })
        }
    }
    const obj = {
        UserID: UserID,
        FirstName: FirstName,
        LastName: LastName,
        Email: Email,
        PassportNumber: PassportNumber,
        Age: Age,
        PhoneNumber: PhoneNumber,
    }
    return (
        <div className="create">
            <h2>Update User</h2>
            <form>
                <label>Enter User's ID to be updated </label>
                <input
                    type="text"
                    required

                    name="UserID"
                    onChange={(e) => setID(e.target.value)}
                />



                <label>Enter The Updated First Name </label>
                <input
                    type="text"

                    // value={flightNumber}
                    name="FirstName"
                    onChange={(e) => setFirstName(e.target.value)}
                />
                <label> Enter The Updated Second Name</label>
                <input

                    type="text"

                    //  value={arrivalTime}
                    name="SecondName"
                    onChange={(e) => setLastName(e.target.value)}
                />
                <label>Enter Updated Email</label>
                <textarea


                    //  value={departure}
                    name="Email"
                    onChange={(e) => setEmail(e.target.value)}
                ></textarea>

                <label>Enter Updated Passport Number</label>
                <textarea


                    //  value={departure}
                    name="PassportNumber"
                    onChange={(e) => setPassportNumber(e.target.value)}
                ></textarea>



                <label>Enter Updated Age</label>
                <textarea


                    //  value={economySeats}
                    name="Age"
                    onChange={(e) => setAge(e.target.value)}
                ></textarea>
                <label>Enter Updated Phone Number</label>
                <textarea

                    //    value={businessSeats}
                    name="PhoneNumber"
                    onChange={(e) => setPhoneNumber(e.target.value)}
                ></textarea>


                <button onClick={handleClick}>Update</button>
            </form>
            <h4>{message}</h4>
        </div>
    );





}
export default UpdateUser;