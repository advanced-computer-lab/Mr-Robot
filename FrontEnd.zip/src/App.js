import React from "react";
import { Component } from 'react';
import Home from '../src/Components/Home'
import users from "./Components/users";
import Viewreservedflights from "./Components/Viewreservedflights";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  useHistory
} from "react-router-dom";
import './App.css';
import { useState, useEffect } from "react";
import UserSearchResult from './Components/UserSearchResults'
import axios, { Axios } from "axios"
import UserSearchFlight from './Components/UserSearchFlight'
import Flights from './Components/Flights';
import CreateFlight from './Components/CreateFlights';
import SearchFlights from './Components/SearchFlights';
import SearchResults from './Components/SearchResults'
import UpdateFlight from './Components/UpdateFlight'
import DeleteFlight from './Components/DeleteFlight';
import SeatNumber from './Components/SeatNumber'
import SecondPopup from './Components/SecondPopup'
import Searcher from './Components/Searcher'
import SearcherFinal from './Components/SearcherFinal'


function App() {
  const [data, setData] = React.useState(null);
  const [searchValues, setSearchValues] = useState([])
  const [FlightDetails, setFlightDetails] = useState([])
  const [ReturnedFlights, setReturnedFlights] = useState([])
  const [PrevFlights, setPrevFlights] = useState([])

  const sentObj = {};


  return (
    <>

      <Router>
        <nav className='navbar'>
          <Link to="/"> Home</Link>
          <Link to="/viewFlights"> View Flights</Link>
          <Link to="/createflight"> Create Flight</Link>
          <Link to="/searchflight"> Book Flight</Link>
          <Link to="/searchfinal"> Search Flight</Link>
          <Link to="/updateFlight"> Update Flight</Link>
          <Link to="/deleteflight"> Delete Flight</Link>
          <Link to="/usersearchFlight"> User Search Flight</Link>
          <Link to="/Viewreservedflights"> View Reserved Flights</Link>
          <Link to="/users"> User Info</Link>
          {/* <Navbar /> */}
        </nav>
        <Switch>
          <Route path="/createFlight" exact component={CreateFlight} />
          <Route path="/" exact component={Home} />
          <Route path="/viewflights" exact component={Flights} />
          <Route path="/searchflight" exact component={SearchFlights} />
          <Route path="/searchfinal" exact component={Searcher} />
          <Route path="/searchfinalresults" exact component={SearcherFinal} />
          <Route path="/searchresults" exact component={SearchResults} />
          <Route path="/usersearchFlight" exact component={UserSearchFlight} />
          <Route path="/usersearchResults" exact component={UserSearchResult} />
          <Route path="/updateFlight" exact component={UpdateFlight} />
          <Route path="/deleteflight" exact component={DeleteFlight} />
          <Route path="/users" exact component={users} />

          <Route path="/Viewreservedflights" exact component={Viewreservedflights} />
          <Route path="/showSummary" exact component={ShowSummary} />
          <Route path="/viewDetails" exact component={ViewDetails} />
          {/* <Route path="/searchresults" exact component={SearchResults}
          /> */}
          <Route path="/seatnumber" exact component={SeatNumber} />
          {/* <Route path="/showSummary" exact component={() => <ShowSummary SelectedFlight={FlightDetails} PrevFlights={PrevFlights} />} /> */}
          <Route path="/seatnumber" exact component={ShowSummary} />
        </Switch>
      </Router>
    </>
  );









  function ShowSummary() {
    const [popUpBtn, setPopUpBtn] = useState(false);

    console.log('XXXXXXX')
    console.log(FlightDetails)
    console.log(PrevFlights)
    console.log('XXXXXXX')

    return <div>
      <h1>Summary of your Bookings</h1>
      <h4>Your First Flight</h4>
      <div className='flights'>
        <ul >
          {typeof FlightDetails.bookingNumber != 'undefined' ? <div> <li>bookingNumber : {FlightDetails.bookingNumber}</li></div>
            : ""}
          <li>ArrivalAirport : {FlightDetails.ArrivalAirport} </li>
          <li>DepartureAirport : {FlightDetails.DepartureAirport} </li>
          <li>Arrival Date : {FlightDetails.ArrivalDate} </li>
          <li> Arrival Terminal : {FlightDetails.ArrivalTerminal} </li>
          <li> Arrival Time : {FlightDetails.ArrivalTime} </li>
          <li> Departure Date : {FlightDetails.DepartureDate} </li>
          <li> Departure Terminal : {FlightDetails.DepartureTerminal}</li>
          <li> Departure Time : {FlightDetails.DepartureTime}</li>
          <li>Flight Price : {FlightDetails.TotalPrice}</li>
          {FlightDetails.Cabin == 'Economy' ? <div> <li>Selected Economy Seat : {FlightDetails.SelectedEconomySeat}</li></div> : <div> <li>Selected Business Seat : {FlightDetails.SelectedBusinessSeat}</li></div>}

        </ul>
      </div>
      <h4>Your Return Flight</h4>
      <div className='flights'>
        <ul>
          {typeof PrevFlights.bookingNumber != 'undefined' ? <div> <li>bookingNumber : {PrevFlights.bookingNumber}</li></div>
            : ""}
          <li>ArrivalAirport : {PrevFlights.ArrivalAirport} </li>
          <li>DepartureAirport : {PrevFlights.DepartureAirport} </li>
          <li>Arrival Date : {PrevFlights.ArrivalDate} </li>
          <li> Arrival Terminal : {PrevFlights.ArrivalTerminal} </li>
          <li> Arrival Time : {PrevFlights.ArrivalTime} </li>
          <li> Departure Date : {PrevFlights.DepartureDate} </li>
          <li> Departure Terminal : {PrevFlights.DepartureTerminal}</li>
          <li> Departure Time : {PrevFlights.DepartureTime}</li>
          <li> Flight Price : {PrevFlights.TotalPrice}</li>
          {PrevFlights.Cabin == 'Economy' ? <div> <li>Selected Economy Seat : {PrevFlights.PrevEconomySeat}</li></div> : <div> <li>Selected Business Seat : {PrevFlights.PrevBusinessSeat}</li></div>}
        </ul>
      </div>
      <h2>The Total Price is {FlightDetails.TotalPrice + PrevFlights.TotalPrice}</h2>
      <Link className="edit" to="/showSummary" onClick={() => setPopUpBtn(true)} >Book Now</Link>
      <SecondPopup trigger={popUpBtn} setTrigger={setPopUpBtn} SelectedFlights={FlightDetails} PrevFlights={PrevFlights}>Confirm Your Booking?</SecondPopup>

    </div>
  }




  function Users() {
    return <h2>Users</h2>;
  }




  function SeatNumber() {

    //console.log("selected:"+SelectedFlight.AvailableEconomySeats[0]);
    //console.log("prev"+PrevFlights.AvailableEconomySeats);
    const [selectedEconomy, setSelectedEconomy] = useState([])
    const [PrevEconomy, setPrevEconomy] = useState([])
    const [selectedBusiness, setSelectedBusiness] = useState('')
    const [PrevBusiness, setPrevBusiness] = useState('')
    const [price, setPrice] = useState(0)
    let history = useHistory();

    function handleClick() {
      const updatedSelectedFlight = FlightDetails
      if (FlightDetails.Cabin == 'Economy') {
        const selectedEconomyArray = selectedEconomy.split(",");
        const selectedPrice = selectedEconomyArray.length * FlightDetails.EconomySeatPrice
        const price = selectedPrice;
        updatedSelectedFlight['SelectedEconomySeat'] = selectedEconomy
        updatedSelectedFlight['TotalPrice'] = selectedPrice
        setFlightDetails(updatedSelectedFlight);
      } else {
        const selectedBusinessArray = selectedBusiness.split(",");
        const selectedPrice = selectedBusinessArray.length * FlightDetails.BusinessClassSeatPrice
        const price = selectedPrice;
        updatedSelectedFlight['SelectedBusinessSeat'] = selectedBusiness
        updatedSelectedFlight['TotalPrice'] = selectedPrice
        setFlightDetails(updatedSelectedFlight)
      }

      const updatedPrevFlight = PrevFlights
      if (PrevFlights.Cabin == 'Economy') {
        const prevEconomyArray = PrevEconomy.split(",");
        const prevPrice = prevEconomyArray.length * PrevFlights.EconomySeatPrice

        updatedPrevFlight['PrevEconomySeat'] = PrevEconomy
        updatedPrevFlight['TotalPrice'] = prevPrice
        setPrevFlights(updatedPrevFlight)
      } else {
        const prevBusinessArray = PrevBusiness.split(",");
        const prevPrice = prevBusinessArray.length * PrevFlights.BusinessClassSeatPrice
        updatedPrevFlight['PrevBusinessSeat'] = PrevBusiness
        updatedPrevFlight['TotalPrice'] = prevPrice
        setPrevFlights(updatedPrevFlight)
      }
      const printer = FlightDetails.TotalPrice + PrevFlights.TotalPrice;
      console.log('The total price is ' + printer)

      history.push('showSummary')
    }
    return (
      <div>

        <h1>Please choose your Seat Number for {PrevFlights.DepartureTerminal} to {PrevFlights.ArrivalTerminal} Flight</h1>

        <div className="checkbox">
          {PrevFlights.Cabin == 'Economy' ? <div>
            <h4>EconomySeats</h4>
            {PrevFlights.AvailableEconomySeats.map(Economyseat => {
              return (
                <div>
                  <td>{Economyseat}</td>
                </div>
              )
            })}
            <input type="text"
              placeholder="EX:A0,A1,A2..."
              onChange={(e) => setPrevEconomy(e.target.value)}
            >
            </input>
          </div> : <div>
              <h4>Business seats</h4>
              {PrevFlights.AvailableBusinessSeats.map(BusinessSeat => {
                return (
                  <div>
                    <td>{BusinessSeat}</td>
                  </div>
                )
              })}
              <input type="text"
                placeholder="EX:A0,A1,A2..."
                onChange={(e) => setPrevBusiness(e.target.value)}
              >
              </input>
            </div>}
        </div>
        <h1>Please choose your Seat Number for {FlightDetails.DepartureTerminal} to {FlightDetails.ArrivalTerminal} Flight</h1>
        <div className="checkbox">
          {FlightDetails.Cabin == 'Economy' ? <div>
            <h4>EconomySeats</h4>
            {FlightDetails.AvailableEconomySeats.map(Economyseat => {

              return (<div>
                <td>{Economyseat}</td>
              </div>
              )
            })}
            <input type="text"
              placeholder="EX:A0,A1,A2..."
              onChange={(e) => setSelectedEconomy(e.target.value)}
            >
            </input>
          </div>
            : <div>
              <h4>Business seats</h4>
              {FlightDetails.AvailableBusinessSeats.map(BusinessSeat => {
                return (
                  <div>
                    <td>{BusinessSeat}</td>
                  </div>)
              })}
              <input type="text" placeholder="EX:A0,A1,A2..."
                onChange={(e) => setSelectedBusiness(e.target.value)} ></input>
            </div>}
          <Link className="edits" to="/showSummary" onClick={handleClick}>Continue Booking</Link>

        </div>
      </div>
    );
  }





  function ViewDetails() {
    let history = useHistory();
    function chooseFlight(flight) {
      setPrevFlights(flight);
    }
    return (
      <div>
        <h1>Your Selected Flight</h1>
        <div className='flights'>
          <ul>
            <li>Flight Number : {FlightDetails.FlightNumber}</li>
            <li> Departure Time : {FlightDetails.DepartureTime}</li>
            <li>Arrival Time : {FlightDetails.ArrivalTime}</li>
            <li>Arrival Date : {FlightDetails.ArrivalDate}</li>
            <li> Departure Date : {FlightDetails.DepartureDate}</li>
            <li> Arrival Terminal : {FlightDetails.ArrivalTerminal}</li>
            <li> Departure Terminal : {FlightDetails.DepartureTerminal}</li>
            <li>Available Economy Seats : {FlightDetails.EconomySeats}</li>
            <li>Available Business Class Seats : {FlightDetails.BusinessClassSeats}</li>
            <li>ArrivalAirport : {FlightDetails.ArrivalAirport} </li>
            <li>DepartureAirport : {FlightDetails.DepartureAirport} </li>
            <li>  Cabin : {FlightDetails.Cabin}</li>
          </ul>
        </div>
        <h1>Select a Return Flight</h1>
        { ReturnedFlights ? ReturnedFlights.map(flight => {
          { console.log(flight) }
          return <div className='flights'>
            <ul >
              <li>Flight Number : {flight.FlightNumber} </li>
              <li>Arrival Time : {flight.ArrivalTime} </li>
              <li> Departue Date : {flight.DepartureDate} </li>
              <li> Arrival Terminal : {flight.ArrivalTerminal} </li>
              <li> Departure Terminal : {flight.DepartureTerminal} </li>
              <li> Economy Seats : {flight.EconomySeats}</li>
              <li> Business Class Seats : {flight.BusinessClassSeats}</li>
              <li>ArrivalAirport : {FlightDetails.ArrivalAirport} </li>
              <li>DepartureAirport : {FlightDetails.DepartureAirport} </li>

              <hr></hr>
              <Link to="/seatnumber" onClick={() => {
                history.push('/seatnumber')
                chooseFlight(flight);
              }} className="edit"> Book Flight</Link>
            </ul>
          </div>
        }) : <h1>Loading</h1>}
      </div>
    );
  }

  function SearchResults() {
    let history = useHistory();

    useEffect(() => {
      receivedata();
    }, [searchValues])

    const receivedata = async () => {
      await axios.get('http://localhost:3001/getresults').then((response) => {
        setSearchValues(response.data)
        //  console.log(searchValues);
        //   console.log("holaaaa")
        //  console.log(searchValues.length)
      }).catch(err => {
        console.log(err)
        console.log("i am here")

      })
    }

    function handleClick() {
      history.push('/viewDetails')
    }

    const updateFriend = (FlightNumber) => {
      setFlightDetails(FlightNumber)

      console.log('hoeeaaa')
      console.log(FlightDetails)
      console.log('xxxxxx')
      sentObj['ArrivalTerminal'] = FlightDetails.DepartureTerminal
      sentObj['DepartureTerminal'] = FlightDetails.ArrivalTerminal
      console.log('sent object')
      console.log(sentObj)
      axios.post('http://localhost:3001/getOpposite', sentObj).then(() => {
        console.log("yes");
      }).catch(err => {
        console.log(err)
        console.log("i am here")
      })


      axios.get('http://localhost:3001/sendOpposite').then((response) => {
        console.log('this is the returned flights')
        setReturnedFlights(response.data)
        console.log(ReturnedFlights);

      }).catch(err => {
        console.log(err)
        console.log("i am here")

      })




    }
    return (
      <div>
        {searchValues.length !== 0 || typeof searchValues != undefined ? searchValues.map(flight => {
          return <div className="flights">
            <ul >
              <li>Flight Number : {flight.FlightNumber} </li>
              <li> Arrival Terminal : {flight.ArrivalTerminal} </li>
              <li> Departure Terminal : {flight.DepartureTerminal} </li>

            </ul>
            <Link className="edit" to="/viewDetails" onClick={() => {
              history.push('/viewDetails')
              console.log(flight)
              console.log('this is the flight passed to updatefirend')
              updateFriend(flight)
            }}>Select Flight</Link>
          </div>
        }) : <h1>No Results Found</h1>
        }
      </div>
    );
  }
}
export default App;