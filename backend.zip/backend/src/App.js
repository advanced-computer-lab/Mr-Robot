// External variables
const express = require("express");
const mongoose = require('mongoose');
// THIS IS WRONG NEVER DO THAT !! Only for the task we put the DB Link here!! NEVER DO THAAAT AGAIN !!
const MongoURI = "mongodb+srv://mariamheshamaly:mrrobot@cluster0.w6ioz.mongodb.net/Cluster0?retryWrites=true&w=majority";

const router = express.Router();
//App variables
const app = express();
const cors = require('cors')
const port = process.env.PORT || "3001";
const User = require('./models/User');
const Flights = require('./Models/Flights');
const Reservation = require('./Models/reservedflights');
const Admin = require('./models/Adminstrator'); app.use(express.json());
const updateObj2 = {};
const obj2 = {};
const array = [];
// #Importing the userController
app.use(cors())
const obj = {}
const Oppositeobj = {}
const updateObj = {}
const createdobj = {}
const reserveobj = {}
app.use("/", require("./Routes/flightsRoute"))
// app.use("/", require("./Routes/searchFlightRoute"))
// configurations
// Mongo DB
mongoose.connect(MongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(result => console.log("MongoDB is now connected"))
  .catch(err => console.log(err));

/*
                                                    Start of your code
*/
app.get("/Home", (req, res) => {
  res.status(200).send("You have everything installed !");
});

app.get("/api", (req, res) => {
  res.json({ message: "Hello from server!" });
});






// router.route("/searchflight").post((req, res) => {
//   const FlightNumber = req.body.FlightNumber;
//   const DepartureTime = req.body.DepartureTime;
//   const ArrivalTime = req.body.ArrivalTime;
//   const ArrivalDate = req.body.ArrivalDate;
//   const DepartureDate = req.body.DepartureDate;
//   const ArrivalTerminal = req.body.ArrivalTerminal;
//   const DepartureTerminal = req.body.DepartureTerminal;

//   global.newFlight = new Flight({
//     FlightNumber,
//     DepartureTime,
//     ArrivalTime,
//     ArrivalDate,
//     DepartureDate,
//     ArrivalTerminal,
//     DepartureTerminal,
//   })
//   console.log(newFlight)

// })


app.post("/UserSearchFlight", (req, res) => {
  var arrivalTime = req.body.ArrivalTime
  var departuretime = req.body.DepartureTime
  var departuredate = req.body.DepartureDate
  var arrivaldate = req.body.ArrivalDate
  var arrivalterminal = req.body.ArrivalTerminal
  var departureterminal = req.body.DepartureTerminal
  var departureairport = req.body.DepartureAirport
  var arrivalairport = req.body.ArrivalAirport
  var childrenseats = req.body.ChildrenSeats
  var adultseats = req.body.AdultSeats
  var tripduration = req.body.TripDuration
  var cabin = req.body.Cabin
  var baggage = req.body.Baggage


  //console.log("checkerrr")
  console.log(tripduration);
  console.log(cabin);



  if (arrivalTime != "") {
    obj2['ArrivalTime'] = arrivalTime
  }
  if (departuretime != "") {
    obj2['DepartureTime'] = departuretime
  }
  if (departuredate != "") {
    obj2['DepartureDate'] = departuredate
  }
  if (arrivaldate != "") {
    obj2['ArrivalDate'] = arrivaldate
  }
  if (departureterminal != "") {
    obj2['DepartureTerminal'] = departureterminal
  }

  if (arrivalterminal != "") {
    obj2['ArrivalTerminal'] = arrivalterminal
  }
  if (departureairport != "") {
    obj2['DepartureAirport'] = departureairport
  }
  if (arrivalairport != "") {
    obj2['ArrivalAirport'] = arrivalairport
  }
  if (tripduration != "") {
    obj2['TripDuration'] = tripduration
  }
  if (cabin != 0) {
    obj2['Cabin'] = cabin
  }
  console.log("mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm")
  console.log(obj2)

  Flights.find(obj2, (err, result) => {
    if (err) {
      console.log(err)
      console.log("Error in find method")
    } else {
      console.log("alyyyyyy")
      console.log(result)
      for (i = 0; i < result.length; i++) {
        console.log("vvvvvvvvvvvvvvvvvvv")
        console.log(result[i]);
        console.log('asharaaaaaaaaaf')
        console.log(result[0].ChildrenSeats)
        console.log(req.body.ChildrenSeats)
        if (result[i].ChildrenSeats >= req.body.ChildrenSeats && result[i].AdultSeats >= req.body.AdultSeats && result[i].Baggage >= req.body.Baggage) {
          array.push(result[i])


        }
      }
      console.log("yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy" + array)
      console.log("miiiiirooooo" + array.length)
      res.send(array)


    }
  })

});



app.post("/searchflight", (req, res) => {


  //db.payments.find({ $where: function() { var value =  isString(this._id) && hex_md5(this._id) == '57fee1331906c3a8f0fa583d37ebbea9'; return value; }}).pretty()
  var flightNumber = req.body.FlightNumber;
  var arrivalTime = req.body.ArrivalTime
  var departuretime = req.body.DepartureTime
  var departuredate = req.body.DepartureDate
  var arrivaldate = req.body.ArrivalDate
  var arrivalterminal = req.body.ArrivalTerminal
  var departureterminal = req.body.DepartureTerminal


  if (flightNumber != "") {
    obj['FlightNumber'] = flightNumber
  }
  if (arrivalTime != "") {
    obj['ArrivalTime'] = arrivalTime
  }
  if (departuretime != "") {
    obj['DepartureTime'] = departuretime
  }
  if (departuredate != "") {
    obj['DepartureDate'] = departuredate
  }
  if (arrivaldate != "") {
    obj['ArrivalDate'] = arrivaldate
  }
  if (departureterminal != "") {
    obj['DepartureTerminal'] = departureterminal
  }

  if (arrivalterminal != "") {
    obj['ArrivalTerminal'] = arrivalterminal
  }




  Flights.find(obj, (err, result) => {
    if (err) {
      console.log(err)
    } else {
      res.send(result)

    }
  })

});
app.get("/getResults", (req, res) => {
  //res.status(200).send(User.find({ Job: 'Avenger' }))
  Flights.find(obj, (req, result) => {
    res.send(result)
  })
});

app.post('/getOpposite', (req, res) => {
  arrivalTerminal = req.body.ArrivalTerminal;
  departureTerminal = req.body.DepartureTerminal;
  Oppositeobj['ArrivalTerminal'] = arrivalTerminal
  Oppositeobj['DepartureTerminal'] = departureTerminal
  console.log('Opposite Object')
  console.log(Oppositeobj);
})

app.get('/sendOpposite', (req, res) => {
  console.log('oppositeobj in the sendopposite')
  console.log(Oppositeobj)
  Flights.find(Oppositeobj, (req, result) => {
    console.log("this is the result")
    console.log(result)
    res.send(result);
  })
})

app.get("/getResults2", (req, res) => {

  Flights.find(obj2, (req, result) => {


    res.send(array)
  })
});


app.put('/update', (req, res) => {
  console.log(req)
  const flightN = req.body.flightN
  const newFlightNumber = req.body.newFlight
  const arrivalT = req.body.arrivalT
  const DepartureTime = req.body.DepartureTime
  const DepartureDate = req.body.DepartureDate
  const ArrivalDate = req.body.ArrivalDate
  const economy = req.body.economy
  const business = req.body.business
  const Airport = req.body.Airport
  const ArrivalTerminal = req.body.ArrivalTerminal
  const DepartureTerminal = req.body.DepartureTerminal


  if (newFlightNumber != "") {
    updateObj['FlightNumber'] = newFlightNumber
  }
  if (arrivalT != "") {
    updateObj['ArrivalTime'] = arrivalT
  }
  if (DepartureTime != "") {
    updateObj['DepartureTime'] = DepartureTime
  }
  if (DepartureDate != "") {
    updateObj['DepartureDate'] = DepartureDate
  }
  if (ArrivalDate != "") {
    updateObj['ArrivalDate'] = ArrivalDate
  }
  if (DepartureTerminal != "") {
    updateObj['DepartureTerminal'] = DepartureTerminal
  }

  if (ArrivalTerminal != "") {
    updateObj['ArrivalTerminal'] = ArrivalTerminal
  }

  if (economy != "") {
    updateObj['ArrivalTerminal'] = economy
  }
  if (business != "") {
    updateObj['ArrivalTerminal'] = business
  }
  if (Airport != "") {
    updateObj['ArrivalTerminal'] = Airport
  }
  Flights.updateOne({ FlightNumber: flightN }, updateObj).clone().then(result => {
    console.log(result)
    if (result.modifiedCount == 1) {
      res.send("Flight Updated")
    } else {
      res.send("flight does not exist")
    }

  })
    .catch(err => {
      console.error(`Failed to add review`)
      res.send("flight does not exists")
    }
    )
})

app.get("/viewFlights", (req, res) => {

  //res.status(200).send(User.find({ Job: 'Avenger' }))
  Flights.find({}, (req, values) => {
    res.json({ message: values });

  })
});

app.get("/getAdmin", (req, res) => {
  //res.status(200).send(User.find({ Job: 'Avenger' }))
  Admin.find({ Name: 'Mohamed Ashraf' }, (req, values) => {
    res.json({ message: values });

  })
});




app.post('/reserve', (req, res) => {
  console.log(req + "sds")
  const FlightNumber = req.body.FlightNumber;
  const DepartureTime = req.body.DepartureTime;
  const ArrivalTime = req.body.ArrivalTime;
  const ArrivalDate = req.body.ArrivalDate;
  const DepartureDate = req.body.DepartureDate;
  const ArrivalTerminal = req.body.ArrivalTerminal;
  const DepartureTerminal = req.body.DepartureTerminal;
  const EconomySeats = req.body.EconomySeats;
  const BusinessClassSeats = req.body.BusinessClassSeats;
  const SelectedEconomySeat = req.body.SelectedEconomySeat;
  const PrevEconomySeat = req.body.PrevEconomySeat;
  const SelectedBusinessSeat = req.body.SelectedBusinessSeat;
  const PrevBusinessSeat = req.body.PrevBusinessSeat
  const Airport = req.body.Airport;
  const TotalPrice = req.body.TotalPrice
  const bookingNumber = req.body.bookingNumber
  const UserID = 992
  const UserEmail = 'mariam.x.salem@gmail.com';


  const newReservation = new Reservation({
    UserID,
    UserEmail,
    FlightNumber,
    DepartureTime,
    ArrivalTime,
    ArrivalDate,
    DepartureDate,
    ArrivalTerminal,
    DepartureTerminal,
    EconomySeats,
    BusinessClassSeats,
    Airport,
    SelectedEconomySeat,
    PrevEconomySeat,
    TotalPrice,
    SelectedBusinessSeat,
    PrevBusinessSeat,
    bookingNumber

  })

  newReservation.save();


})



app.put('/reserveupdate', (req, res) => {
  const FlightNumber = req.body.FlightNumber;
  let BusinessClassSeats = req.body.BusinessClassSeats;
  const SelectedEconomySeat = req.body.SelectedEconomySeat;
  const PrevEconomySeat = req.body.PrevEconomySeat;
  const SelectedBusinessSeat = req.body.SelectedBusinessSeat;
  let PrevBusinessSeat = req.body.PrevBusinessSeat;
  let EconomySeats = req.body.EconomySeats;
  let AvailableBusinessSeats = req.body.AvailableBusinessSeats
  let AvailableEconomySeats = req.body.AvailableEconomySeats
  res.send('updated')

  if (typeof SelectedBusinessSeat != 'undefined') {
    console.log('HOLAAAAAA')
    console.log(req.body.SelectedBusinessSeat)

    if (SelectedBusinessSeat.split(',').length > 1) {
      //Not Handeled Yet
      const newArr = SelectedBusinessSeat.split(',')
      for (let i = 0; i < newArr.length; i++) {
        const index = AvailableBusinessSeats.indexOf(newArr[i]);
        const BusinessSeats = BusinessClassSeats - 1;
        BusinessClassSeats = BusinessSeats;
        const returnedArr = AvailableBusinessSeats.filter(e => e !== AvailableBusinessSeats[index])
        AvailableBusinessSeats = returnedArr;
        reserveobj['AvailableBusinessSeats'] = returnedArr;
        reserveobj['BusinessClassSeats'] = BusinessSeats;
        console.log('away obj ' + i);
        console.log(reserveobj)
        Flights.updateOne({ FlightNumber: FlightNumber }, reserveobj, (error, doc) => {
          if (error) {
            console.log(error);
            // res.redirect(‘/’);
            return;
          }
        })
      }
    } else {
      //Handled
      const index = AvailableBusinessSeats.indexOf(req.body.SelectedBusinessSeat);
      console.log(index)
      const BusinessSeats = BusinessClassSeats - 1;
      const newArr = AvailableBusinessSeats.filter(e => e !== AvailableBusinessSeats[index])
      reserveobj['AvailableBusinessSeats'] = newArr;
      reserveobj['BusinessClassSeats'] = BusinessSeats;
      Flights.updateOne({ FlightNumber: FlightNumber }, reserveobj, (error, doc) => {
        if (error) {
          console.log(error);
          // res.redirect(‘/’);
          return;
        }
      })
    }

  } else if (typeof PrevBusinessSeat != 'undefined') {

    //Not Handeled Yet
    if (PrevBusinessSeat.split(',').length > 1) {
      //Not Handeled Yet
      const newArr = PrevBusinessSeat.split(',')
      for (let i = 0; i < newArr.length; i++) {
        const index = AvailableBusinessSeats.indexOf(newArr[i]);
        const BusinessSeats = BusinessClassSeats - 1;
        BusinessClassSeats = BusinessSeats;
        const returnedArr = AvailableBusinessSeats.filter(e => e !== AvailableBusinessSeats[index])
        AvailableBusinessSeats = returnedArr;
        reserveobj['AvailableBusinessSeats'] = returnedArr;
        reserveobj['BusinessClassSeats'] = BusinessSeats;
        console.log('Home obj ' + i);
        console.log(reserveobj)
        Flights.updateOne({ FlightNumber: FlightNumber }, reserveobj, (error, doc) => {
          if (error) {
            console.log(error);
            // res.redirect(‘/’);
            return;
          }
        })
      }
    } else {
      //handled
      const index = AvailableBusinessSeats.indexOf(req.body.PrevBusinessSeat);
      console.log(index)
      const BusinessSeats = BusinessClassSeats - 1;
      const newArr = AvailableBusinessSeats.filter(e => e !== AvailableBusinessSeats[index])
      reserveobj['AvailableBusinessSeats'] = newArr;
      reserveobj['BusinessClassSeats'] = BusinessSeats;
      Flights.updateOne({ FlightNumber: FlightNumber }, reserveobj, (error, doc) => {
        if (error) {
          console.log(error);
          // res.redirect(‘/’);
          return;
        }
      })
    }
  } else if (typeof SelectedEconomySeat != 'undefined') {


    if (SelectedEconomySeat.split(',').length > 1) {
      //Not Handled
      console.log('HOLAAAAAA')
      console.log(req.body.SelectedBusinessSeat)

      if (SelectedEconomySeat.split(',').length > 1) {
        //Not Handeled Yet
        const newArr = SelectedEconomySeat.split(',')
        for (let i = 0; i < newArr.length; i++) {
          const index = AvailableEconomySeats.indexOf(newArr[i]);
          const EconomySeatsNew = EconomySeats - 1;
          EconomySeats = EconomySeatsNew;
          const returnedArr = AvailableEconomySeats.filter(e => e !== AvailableEconomySeats[index])
          AvailableEconomySeats = returnedArr;
          reserveobj['AvailableEconomySeats'] = returnedArr;
          reserveobj['EconomySeats'] = EconomySeatsNew;
          console.log('away obj ' + i);
          console.log(reserveobj)
          Flights.updateOne({ FlightNumber: FlightNumber }, reserveobj, (error, doc) => {
            if (error) {
              console.log(error);
              // res.redirect(‘/’);
              return;
            }
          })
        }
      }
      console.log('i should not be here')
    } else {
      //Handled
      const index = AvailableEconomySeats.indexOf(req.body.SelectedEconomySeat);
      const EconomySeatsNew = EconomySeats - 1;
      const newArr = AvailableEconomySeats.filter(e => e !== AvailableEconomySeats[index])
      reserveobj['AvailableEconomySeats'] = newArr;
      reserveobj['EconomySeats'] = EconomySeatsNew;
      Flights.updateOne({ FlightNumber: FlightNumber }, reserveobj, (error, doc) => {
        if (error) {
          console.log(error);
          // res.redirect(‘/’);
          return;
        }
      })
    }
  } else if (typeof PrevEconomySeat != 'undefined') {
    if (PrevEconomySeat.split(',').length > 1) {
      // Not Handled
      const newArr = PrevEconomySeat.split(',')
      for (let i = 0; i < newArr.length; i++) {
        const index = AvailableEconomySeats.indexOf(newArr[i]);
        const EconomySeatsNew = EconomySeats - 1;
        EconomySeats = EconomySeatsNew;
        const returnedArr = AvailableEconomySeats.filter(e => e !== AvailableEconomySeats[index])
        AvailableEconomySeats = returnedArr;
        reserveobj['AvailableEconomySeats'] = returnedArr;
        reserveobj['EconomySeats'] = EconomySeatsNew;
        console.log('Home obj ' + i);
        console.log(reserveobj)
        Flights.updateOne({ FlightNumber: FlightNumber }, reserveobj, (error, doc) => {
          if (error) {
            console.log(error);
            // res.redirect(‘/’);
            return;
          }
        })
      }
      console.log('i Should not be here');
    } else {
      //handled
      const index = AvailableEconomySeats.indexOf(req.body.PrevEconomySeat);
      const EconomySeatsNew = EconomySeats - 1;
      const newArr = AvailableEconomySeats.filter(e => e !== AvailableEconomySeats[index])
      reserveobj['AvailableEconomySeats'] = newArr;
      reserveobj['EconomySeats'] = EconomySeatsNew;
      Flights.updateOne({ FlightNumber: FlightNumber }, reserveobj, (error, doc) => {
        if (error) {
          console.log(error);
          // res.redirect(‘/’);
          return;
        }
      })
    }
  }
})










app.put('/updateuser', (req, res) => {
  console.log(req)
  const FirstName = req.body.FirstName
  const SecondName = req.body.SecondName
  const UserID = req.body.UserID
  const PassportNumber = req.body.PassportNumber
  const Email = req.body.Email
  const Age = req.body.Age
  const PhoneNumber = req.body.PhoneNumber


  if (FirstName != "") {
    updateObj2['FirstName'] = FirstName
  }
  if (SecondName != "") {
    updateObj2['SecondName'] = SecondName
  }
  if (UserID != "") {
    updateObj2['UserID'] = UserID
  }
  if (PassportNumber != "") {
    updateObj2['PassportNumber'] = PassportNumber
  }
  if (Email != "") {
    updateObj2['Email'] = Email
  }
  if (Age != "") {
    updateObj2['Age'] = Age
  }

  if (PhoneNumber != "") {
    updateObj2['PhoneNumber'] = PhoneNumber
  }
  User.updateOne({ UserID: UserID }, updateObj2,).clone().then(result => {
    console.log(result)
    if (result.modifiedCount == 1) {
      res.send("User Updated")
    } else {
      res.send("User does not exist")
    }
  })
    .catch(err => {
      console.error(`Failed to add review`)
      res.send("User does not exist")
    }
    )
})




app.get("/viewreservedflights", (req, res) => {

  Reservation.find({}, (req, values) => {
    res.json({ message: values });


  })
});



app.put('/update', (req, res) => {
  console.log(req)
  const flightN = req.body.flightN
  const newFlightNumber = req.body.newFlight
  const arrivalT = req.body.arrivalT
  const DepartureTime = req.body.DepartureTime
  const DepartureDate = req.body.DepartureDate
  const ArrivalDate = req.body.ArrivalDate
  const economy = req.body.economy
  const business = req.body.business
  const Airport = req.body.Airport
  const ArrivalTerminal = req.body.ArrivalTerminal
  const DepartureTerminal = req.body.DepartureTerminal


  if (newFlightNumber != "") {
    updateObj['FlightNumber'] = newFlightNumber
  }
  if (arrivalT != "") {
    updateObj['ArrivalTime'] = arrivalT
  }
  if (DepartureTime != "") {
    updateObj['DepartureTime'] = DepartureTime
  }
  if (DepartureDate != "") {
    updateObj['DepartureDate'] = DepartureDate
  }
  if (ArrivalDate != "") {
    updateObj['ArrivalDate'] = ArrivalDate
  }
  if (DepartureTerminal != "") {
    updateObj['DepartureTerminal'] = DepartureTerminal
  }

  if (ArrivalTerminal != "") {
    updateObj['ArrivalTerminal'] = ArrivalTerminal
  }

  if (economy != "") {
    updateObj['ArrivalTerminal'] = economy
  }
  if (business != "") {
    updateObj['ArrivalTerminal'] = business
  }
  if (Airport != "") {
    updateObj['ArrivalTerminal'] = Airport
  }






  // Flights.findById(900, (error, flightToUpdate) => {


  //   console.log(flightToUpdate + "nksnkjdnjn")
  //   // flightToUpdate.ArrivalTime = arrivalT
  //   // flightToUpdate.DepartureTime = DepartureTime
  //   // flightToUpdate.DepartureDate = DepartureDate
  //   // flightToUpdate.ArrivalDate = ArrivalDate
  //   // flightToUpdate.EconomySeats = economy
  //   // flightToUpdate.BusinessClassSeats = business
  //   // flightToUpdate.Airport = Airport
  //   // flightToUpdate.ArrivalTerminal = ArrivalTerminal
  //   // flightToUpdate.DepartureTerminal = DepartureTerminal
  //   // flightToUpdate.save();

  // })

  Flights.updateOne({ FlightNumber: flightN }, updateObj, (error, doc) => {
    if (error) {
      console.log(error);
      // res.redirect(‘/’);
      return;
    }
  })
  res.send('updated')
})





app.post("/createFlight", (req, res) => {

  const flightN = req.body.flightN
  const arrivalT = req.body.arrivalT
  const DepartureTime = req.body.DepartureTime
  const DepartureDate = req.body.DepartureDate
  const ArrivalDate = req.body.ArrivalDate
  const economy = req.body.economy
  const business = req.body.business
  const Airport = req.body.Airport
  const ArrivalTerminal = req.body.ArrivalTerminal
  const DepartureTerminal = req.body.DepartureTerminal
  if (flightN != "") {
    createdobj['FlightNumber'] = flightN
  }
  if (arrivalT != "") {
    createdobj['ArrivalTime'] = arrivalT
  }
  if (DepartureTime != "") {
    createdobj['DepartureTime'] = DepartureTime
  }
  if (DepartureDate != "") {
    createdobj['DepartureDate'] = DepartureDate
  }
  if (ArrivalDate != "") {
    createdobj['ArrivalDate'] = ArrivalDate
  }
  if (DepartureTerminal != "") {
    createdobj['DepartureTerminal'] = DepartureTerminal
  }

  if (ArrivalTerminal != "") {
    createdobj['ArrivalTerminal'] = ArrivalTerminal
  }

  if (economy != "") {
    createdobj['ArrivalTerminal'] = economy
  }
  if (business != "") {
    createdobj['ArrivalTerminal'] = business
  }
  if (Airport != "") {
    createdobj['ArrivalTerminal'] = Airport
  }

  createdobj['AvailableSeats'].push('A0')
  createdobj['AvailableSeats'].push('A1')
  createdobj['AvailableSeats'].push('A2')

  createdobj.save(function (err) {
    if (err) {
      console.log(err + "hello");
      throw err;

    } else {
      console.log("Saved")
    }
  })
});


app.post("/addAdmin", (req, res) => {
  const personDocument = new Admin({
    "Name": "Mohamed Ashraf",
    "Email": "mashrafelsaeed@gmail.com",
    "id": 1,
  })
  personDocument.save(function (err) {
    if (err) {
      console.log(err + "hello");
      throw err;

    } else {
      console.log("Saved")
    }
  })
});




// #Routing to usercontroller here




/*
                                                    End of your code
*/

// Starting server
app.listen(port, () => {
  console.log(`Listening to requests on http://localhost:${port}`);
});